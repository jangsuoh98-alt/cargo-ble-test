V4: FFF4 power and brightness controls; foreground reconnect; V3 diagnostics retained.
