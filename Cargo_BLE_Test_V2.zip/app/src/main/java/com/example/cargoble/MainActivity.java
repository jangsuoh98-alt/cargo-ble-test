package com.example.cargoble;
import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.widget.*;
import android.graphics.Color;
import android.view.View;
import java.util.*;

public class MainActivity extends Activity {
 final Handler h=new Handler(Looper.getMainLooper());
 BluetoothAdapter adapter; BluetoothLeScanner scanner; BluetoothGatt gatt;
 boolean scanning=false, ready=false, baselineSet=false;
 final Map<String,ScanResult> found=new HashMap<>();
 final Set<String> baseline=new HashSet<>();
 LinearLayout rows; TextView status, info; Button scan, save, reconnect; String selected=""; String selectedName="";
 int red=0xffb71c1c;
 TextView text(LinearLayout parent,String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setPadding(8,10,8,10);parent.addView(t);return t;}
 Button button(LinearLayout parent,String s,Runnable r){Button b=new Button(this);b.setText(s);parent.addView(b);b.setOnClickListener(v->r.run());return b;}
 @Override public void onCreate(Bundle b){super.onCreate(b); LinearLayout p=new LinearLayout(this);p.setOrientation(1);p.setPadding(20,32,20,24);ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(p);setContentView(sv);
 TextView title=text(p,"CARGO BLE TEST V2",24);title.setTextColor(red);
 status=text(p,"기기 검색 후 본인 기기만 선택하세요.",16);
 scan=button(p,"주변 기기 검색 (12초)",()->start());scan.setTextColor(Color.WHITE);scan.setBackgroundTintList(android.content.res.ColorStateList.valueOf(red));
 button(p,"현재 목록을 비교 기준으로 저장",()->{if(scanning||found.isEmpty()){status.setText("검색 완료 후 저장하세요.");return;}baseline.clear();baseline.addAll(found.keySet());baselineSet=true;render();status.setText("비교 기준 저장 완료. 기기 전원을 켜고 다시 검색하세요.");});
 reconnect=button(p,"저장된 기기 다시 연결",()->{String a=getPreferences(0).getString("address","");if(a.isEmpty()){status.setText("저장된 기기가 없습니다.");return;}if(!permission())return;try{connect(adapter.getRemoteDevice(a),getPreferences(0).getString("name","저장 기기"));}catch(Exception e){status.setText("재연결 실패: "+e.getMessage());}});
 button(p,"연결 해제",()->{closeGatt();status.setText("연결 해제");});
 info=text(p,"통신정보 확인 대기",14);info.setTextIsSelectable(true);
 button(p,"통신정보 복사",()->{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("BLE",info.getText()));Toast.makeText(this,"복사 완료",Toast.LENGTH_SHORT).show();});
 save=button(p,"선택 기기 저장 (1개)",()->{if(ready){getPreferences(0).edit().putString("address",selected).putString("name",selectedName).apply();status.setText("저장 완료: "+selectedName);}});save.setEnabled(false);
 rows=new LinearLayout(this);rows.setOrientation(1);p.addView(rows);
 BluetoothManager m=(BluetoothManager)getSystemService(BLUETOOTH_SERVICE);adapter=m==null?null:m.getAdapter();permission();}
 boolean permission(){String[] ps=Build.VERSION.SDK_INT>=31?new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT}:new String[]{Manifest.permission.ACCESS_FINE_LOCATION};for(String s:ps)if(checkSelfPermission(s)!=PackageManager.PERMISSION_GRANTED){requestPermissions(ps,1);return false;}return true;}
 void start(){if(scanning||!permission())return;try{if(adapter==null||!adapter.isEnabled()){status.setText("블루투스를 켜주세요.");return;}scanner=adapter.getBluetoothLeScanner();if(scanner==null)return;found.clear();scanning=true;scan.setEnabled(false);status.setText("검색 중...");render();scanner.startScan(cb);h.postDelayed(stopTask,12000);}catch(Exception e){stop();status.setText("검색 오류: "+e.getMessage());}}
 final Runnable stopTask=()->stop();
 void stop(){h.removeCallbacks(stopTask);if(scanning){try{scanner.stopScan(cb);}catch(Exception e){}scanning=false;scan.setEnabled(true);status.setText("검색 완료: "+found.size()+"개");render();}}
 final ScanCallback cb=new ScanCallback(){public void onScanResult(int type,ScanResult r){h.post(()->{if(scanning){found.put(r.getDevice().getAddress(),r);}});}public void onScanFailed(int e){h.post(()->{stop();status.setText("검색 실패: "+e);});}};
 String name(ScanResult r){String s=r.getScanRecord()==null?null:r.getScanRecord().getDeviceName();if(s==null)try{s=r.getDevice().getName();}catch(Exception e){}return s==null?"이름 없음":s;}
 void render(){rows.removeAllViews();ArrayList<ScanResult> a=new ArrayList<>(found.values());a.sort((x,y)->Integer.compare(y.getRssi(),x.getRssi()));text(rows,"검색 결과 (신호 강한 순): "+a.size(),18);for(ScanResult r:a){String addr=r.getDevice().getAddress(),nm=name(r);boolean fresh=baselineSet&&!baseline.contains(addr);Button b=button(rows,(fresh?"[새 기기] ":"")+nm+"  "+r.getRssi()+" dBm\n"+addr+"  · 연결",()->connect(r.getDevice(),nm));b.setAllCaps(false);if(fresh)b.setTextColor(red);}}
 void closeGatt(){ready=false;save.setEnabled(false);BluetoothGatt old=gatt;gatt=null;if(old!=null){try{old.disconnect();old.close();}catch(Exception e){}}}
 void connect(BluetoothDevice d,String nm){if(!permission())return;stop();closeGatt();selected=d.getAddress();selectedName=nm;status.setText("연결 중: "+nm);status.setTextColor(Color.DKGRAY);info.setText("선택: "+nm+"\n주소: "+selected);try{gatt=d.connectGatt(this,false,gcb,BluetoothDevice.TRANSPORT_LE);final BluetoothGatt attempt=gatt;h.postDelayed(()->{if(gatt==attempt&&!ready){closeGatt();status.setText("연결/서비스 검색 시간 초과");}},25000);}catch(Exception e){status.setText("연결 오류: "+e.getMessage());}}
 final BluetoothGattCallback gcb=new BluetoothGattCallback(){
 @Override public void onConnectionStateChange(BluetoothGatt g,int code,int state){h.post(()->{if(g!=gatt)return;if(code==0&&state==BluetoothProfile.STATE_CONNECTED){status.setText("● 연결됨: "+selectedName+" / 서비스 검색 중");status.setTextColor(0xff16803c);try{if(!g.discoverServices()){closeGatt();status.setText("서비스 검색 시작 실패");}}catch(Exception e){closeGatt();status.setText("서비스 검색 오류");}}else if(code!=0||state==BluetoothProfile.STATE_DISCONNECTED){closeGatt();status.setTextColor(Color.DKGRAY);status.setText("연결 종료 / 상태 코드: "+code);}});}
 @Override public void onServicesDiscovered(BluetoothGatt g,int code){h.post(()->{if(g!=gatt)return;if(code!=0){closeGatt();status.setText("서비스 검색 실패: "+code);return;}StringBuilder b=new StringBuilder("기기: "+selectedName+"\n주소: "+selected+"\n");for(BluetoothGattService s:g.getServices()){b.append("\n서비스 UUID: ").append(s.getUuid()).append("\n");for(BluetoothGattCharacteristic c:s.getCharacteristics()){int p=c.getProperties();b.append("특성 UUID: ").append(c.getUuid()).append("\n속성: ");if((p&2)!=0)b.append("READ ");if((p&8)!=0)b.append("WRITE ");if((p&4)!=0)b.append("WRITE_NO_RESPONSE ");if((p&16)!=0)b.append("NOTIFY ");if((p&32)!=0)b.append("INDICATE ");b.append("\n");}}info.setText(b.toString());ready=true;save.setEnabled(true);status.setText("● 연결 및 통신정보 확인 완료");});}};
 @Override protected void onDestroy(){stop();closeGatt();h.removeCallbacksAndMessages(null);super.onDestroy();}
}
