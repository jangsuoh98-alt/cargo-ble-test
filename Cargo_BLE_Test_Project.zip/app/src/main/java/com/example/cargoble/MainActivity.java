package com.example.cargoble;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQ = 41;
    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, String> found = new LinkedHashMap<>();
    private TextView status, results;
    private Button scanButton;
    private boolean scanning = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 28, 28, 28);

        TextView title = new TextView(this);
        title.setText("CARGO BLE 진단 도구");
        title.setTextSize(24);
        page.addView(title);

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, 18, 0, 18);
        status.setText("블루투스 권한을 확인합니다.");
        page.addView(status);

        scanButton = new Button(this);
        scanButton.setText("주변 BLE 기기 검색 (12초)");
        page.addView(scanButton);

        results = new TextView(this);
        results.setTextSize(15);
        results.setPadding(0, 18, 0, 0);
        page.addView(results);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(page);
        setContentView(scroll);

        BluetoothManager manager = (BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
        scanButton.setOnClickListener(v -> beginScan());
        ensurePermissions();
    }

    private boolean has(String permission) {
        return Build.VERSION.SDK_INT < 23 ||
            checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void ensurePermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            String[] p = { Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT };
            if (!has(p[0]) || !has(p[1])) {
                requestPermissions(p, REQ);
                return;
            }
        } else if (Build.VERSION.SDK_INT >= 23 && !has(Manifest.permission.ACCESS_FINE_LOCATION)) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ);
            return;
        }
        status.setText("준비 완료. 기기 검색을 눌러주세요.");
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode == REQ) {
            boolean ok = true;
            for (int g : grants) if (g != PackageManager.PERMISSION_GRANTED) ok = false;
            status.setText(ok ? "권한 허용 완료. 검색할 수 있습니다." : "권한이 필요합니다. 앱 설정에서 블루투스 권한을 허용해주세요.");
        }
    }

    private void beginScan() {
        if (scanning) return;
        if (adapter == null) { status.setText("이 휴대폰에서 블루투스를 사용할 수 없습니다."); return; }
        if (Build.VERSION.SDK_INT >= 31 &&
            (!has(Manifest.permission.BLUETOOTH_SCAN) || !has(Manifest.permission.BLUETOOTH_CONNECT))) {
            ensurePermissions(); return;
        }
        if (Build.VERSION.SDK_INT < 31 && Build.VERSION.SDK_INT >= 23 && !has(Manifest.permission.ACCESS_FINE_LOCATION)) {
            ensurePermissions(); return;
        }
        try {
            if (!adapter.isEnabled()) { status.setText("휴대폰 블루투스를 켜주세요."); return; }
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) { status.setText("BLE 검색기를 사용할 수 없습니다."); return; }
            found.clear();
            results.setText("");
            scanning = true;
            scanButton.setEnabled(false);
            status.setText("검색 중... 기기 전원을 켜고 가까이 두세요.");
            scanner.startScan(callback);
            handler.postDelayed(() -> stopScan(), 12000);
        } catch (SecurityException e) {
            scanning = false;
            scanButton.setEnabled(true);
            status.setText("블루투스 권한을 허용한 뒤 다시 시도해주세요.");
        } catch (Exception e) {
            scanning = false;
            scanButton.setEnabled(true);
            status.setText("검색 시작 오류: " + e.getClass().getSimpleName());
        }
    }

    private final ScanCallback callback = new ScanCallback() {
        @Override public void onScanResult(int type, ScanResult result) {
            try {
                BluetoothDevice d = result.getDevice();
                String name = d.getName();
                if (name == null || name.trim().isEmpty()) name = "(이름 없음)";
                String address = d.getAddress();
                String record = name + "\n주소: " + address + "\n신호: " + result.getRssi() + " dBm";
                found.put(address, record);
                runOnUiThread(() -> renderResults());
            } catch (SecurityException ignored) { }
        }
        @Override public void onScanFailed(int errorCode) {
            runOnUiThread(() -> {
                status.setText("BLE 검색 실패 코드: " + errorCode);
                scanning = false;
                scanButton.setEnabled(true);
            });
        }
    };

    private void stopScan() {
        if (!scanning) return;
        try { if (scanner != null) scanner.stopScan(callback); } catch (Exception ignored) { }
        scanning = false;
        scanButton.setEnabled(true);
        status.setText("검색 완료: " + found.size() + "개 기기");
        renderResults();
    }

    private void renderResults() {
        StringBuilder b = new StringBuilder();
        b.append("검색된 기기: ").append(found.size()).append("개\n\n");
        for (String s : found.values()) b.append(s).append("\n\n--------------------\n\n");
        results.setText(b.toString());
    }

    @Override protected void onDestroy() {
        if (scanning) {
            try { scanner.stopScan(callback); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }
}
