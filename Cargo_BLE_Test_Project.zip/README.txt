CARGO BLE Test - Android project

This first test build scans nearby Bluetooth Low Energy (BLE) devices and displays
device name, address, and RSSI. It does NOT send control commands to lamps or fans.

Build:
  gradle assembleDebug

Output:
  app/build/outputs/apk/debug/app-debug.apk

The device protocol must be identified before implementing lamp/fan controls.
