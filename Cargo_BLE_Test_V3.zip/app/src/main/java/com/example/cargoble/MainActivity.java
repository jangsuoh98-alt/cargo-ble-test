package com.example.cargoble;
import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.widget.*;
import android.graphics.Color;
import android.view.View;
import java.util.*;

public class MainActivity extends Activity {
 final Handler h=new Handler(Looper.getMainLooper());
 BluetoothAdapter adapter; BluetoothLeScanner scanner; BluetoothGatt gatt;
 boolean scanning=false, ready=false, baselineSet=false;
 final Map<String,ScanResult> found=new HashMap<>();
 final Set<String> baseline=new HashSet<>();
 LinearLayout rows; TextView log; Button analyze, send; EditText hexInput; Spinner channel; final ArrayDeque<Runnable> ops=new ArrayDeque<>(); boolean busy=false; TextView status, info; Button scan, save, reconnect; String selected=""; String selectedName="";
 int red=0xffb71c1c;
 TextView text(LinearLayout parent,String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setPadding(8,10,8,10);parent.addView(t);return t;}
 Button button(LinearLayout parent,String s,Runnable r){Button b=new Button(this);b.setText(s);parent.addView(b);b.setOnClickListener(v->r.run());return b;}
 @Override public void onCreate(Bundle b){super.onCreate(b); LinearLayout p=new LinearLayout(this);p.setOrientation(1);p.setPadding(20,32,20,24);ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(p);setContentView(sv);
 TextView title=text(p,"CARGO BLE TEST V3",24);title.setTextColor(red);
 status=text(p,"기기 검색 후 본인 기기만 선택하세요.",16);
 scan=button(p,"주변 기기 검색 (12초)",()->start());scan.setTextColor(Color.WHITE);scan.setBackgroundTintList(android.content.res.ColorStateList.valueOf(red));
 button(p,"현재 목록을 비교 기준으로 저장",()->{if(scanning||found.isEmpty()){status.setText("검색 완료 후 저장하세요.");return;}baseline.clear();baseline.addAll(found.keySet());baselineSet=true;render();status.setText("비교 기준 저장 완료. 기기 전원을 켜고 다시 검색하세요.");});
 reconnect=button(p,"저장된 기기 다시 연결",()->{String a=getPreferences(0).getString("address","");if(a.isEmpty()){status.setText("저장된 기기가 없습니다.");return;}if(!permission())return;try{connect(adapter.getRemoteDevice(a),getPreferences(0).getString("name","저장 기기"));}catch(Exception e){status.setText("재연결 실패: "+e.getMessage());}});
 button(p,"연결 해제",()->{closeGatt();status.setText("연결 해제");});
 info=text(p,"통신정보 확인 대기",14);info.setTextIsSelectable(true);
 button(p,"통신정보 복사",()->{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("BLE",info.getText()));Toast.makeText(this,"복사 완료",Toast.LENGTH_SHORT).show();});
 save=button(p,"선택 기기 저장 (1개)",()->{if(ready){getPreferences(0).edit().putString("address",selected).putString("name",selectedName).apply();status.setText("저장 완료: "+selectedName);}});save.setEnabled(false);
 analyze=button(p,"EASY-LIGHT 데이터 읽기 및 알림 수신",()->analyze());analyze.setEnabled(false);
 log=text(p,"통신 기록\n",14);log.setTextIsSelectable(true);
 button(p,"통신 기록 복사",()->((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("BLE log",info.getText()+"\n"+log.getText())));
 channel=new Spinner(this);channel.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"FF01","FC01","FFF4"}));p.addView(channel);hexInput=new EditText(this);hexInput.setHint("확인된 HEX 명령만 입력");p.addView(hexInput);send=button(p,"확인된 명령 수동 전송",()->manual());send.setEnabled(false);
 rows=new LinearLayout(this);rows.setOrientation(1);p.addView(rows);
 BluetoothManager m=(BluetoothManager)getSystemService(BLUETOOTH_SERVICE);adapter=m==null?null:m.getAdapter();permission();}
 boolean permission(){String[] ps=Build.VERSION.SDK_INT>=31?new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT}:new String[]{Manifest.permission.ACCESS_FINE_LOCATION};for(String s:ps)if(checkSelfPermission(s)!=PackageManager.PERMISSION_GRANTED){requestPermissions(ps,1);return false;}return true;}
 void start(){if(scanning||!permission())return;try{if(adapter==null||!adapter.isEnabled()){status.setText("블루투스를 켜주세요.");return;}scanner=adapter.getBluetoothLeScanner();if(scanner==null)return;found.clear();scanning=true;scan.setEnabled(false);status.setText("검색 중...");render();scanner.startScan(cb);h.postDelayed(stopTask,12000);}catch(Exception e){stop();status.setText("검색 오류: "+e.getMessage());}}
 final Runnable stopTask=()->stop();
 void stop(){h.removeCallbacks(stopTask);if(scanning){try{scanner.stopScan(cb);}catch(Exception e){}scanning=false;scan.setEnabled(true);status.setText("검색 완료: "+found.size()+"개");render();}}
 final ScanCallback cb=new ScanCallback(){public void onScanResult(int type,ScanResult r){h.post(()->{if(scanning){found.put(r.getDevice().getAddress(),r);}});}public void onScanFailed(int e){h.post(()->{stop();status.setText("검색 실패: "+e);});}};
 String name(ScanResult r){String s=r.getScanRecord()==null?null:r.getScanRecord().getDeviceName();if(s==null)try{s=r.getDevice().getName();}catch(Exception e){}return s==null?"이름 없음":s;}
 void render(){rows.removeAllViews();ArrayList<ScanResult> a=new ArrayList<>(found.values());a.sort((x,y)->{int k=Boolean.compare(name(y).equalsIgnoreCase("EASY-LIGHT"),name(x).equalsIgnoreCase("EASY-LIGHT"));return k!=0?k:Integer.compare(y.getRssi(),x.getRssi());});text(rows,"검색 결과 (신호 강한 순): "+a.size(),18);for(ScanResult r:a){String addr=r.getDevice().getAddress(),nm=name(r);boolean fresh=baselineSet&&!baseline.contains(addr);Button b=button(rows,(fresh?"[새 기기] ":"")+nm+"  "+r.getRssi()+" dBm\n"+addr+"  · 연결",()->connect(r.getDevice(),nm));b.setAllCaps(false);if(fresh)b.setTextColor(red);}}
 void closeGatt(){h.removeCallbacks(timeout);ops.clear();busy=false;analyze.setEnabled(false);send.setEnabled(false);ready=false;save.setEnabled(false);BluetoothGatt old=gatt;gatt=null;if(old!=null){try{old.disconnect();old.close();}catch(Exception e){}}}
 void connect(BluetoothDevice d,String nm){if(!permission())return;stop();closeGatt();selected=d.getAddress();selectedName=nm;status.setText("연결 중: "+nm);status.setTextColor(Color.DKGRAY);info.setText("선택: "+nm+"\n주소: "+selected);try{gatt=d.connectGatt(this,false,gcb,BluetoothDevice.TRANSPORT_LE);final BluetoothGatt attempt=gatt;h.postDelayed(()->{if(gatt==attempt&&!ready){closeGatt();status.setText("연결/서비스 검색 시간 초과");}},25000);}catch(Exception e){status.setText("연결 오류: "+e.getMessage());}}
 final BluetoothGattCallback gcb=new BluetoothGattCallback(){
 @Override public void onConnectionStateChange(BluetoothGatt g,int code,int state){h.post(()->{if(g!=gatt)return;if(code==0&&state==BluetoothProfile.STATE_CONNECTED){status.setText("● 연결됨: "+selectedName+" / 서비스 검색 중");status.setTextColor(0xff16803c);try{if(!g.discoverServices()){closeGatt();status.setText("서비스 검색 시작 실패");}}catch(Exception e){closeGatt();status.setText("서비스 검색 오류");}}else if(code!=0||state==BluetoothProfile.STATE_DISCONNECTED){closeGatt();status.setTextColor(Color.DKGRAY);status.setText("연결 종료 / 상태 코드: "+code);}});}
 @Override public void onServicesDiscovered(BluetoothGatt g,int code){h.post(()->{if(g!=gatt)return;if(code!=0){closeGatt();status.setText("서비스 검색 실패: "+code);return;}StringBuilder b=new StringBuilder("기기: "+selectedName+"\n주소: "+selected+"\n");for(BluetoothGattService s:g.getServices()){b.append("\n서비스 UUID: ").append(s.getUuid()).append("\n");for(BluetoothGattCharacteristic c:s.getCharacteristics()){int p=c.getProperties();b.append("특성 UUID: ").append(c.getUuid()).append("\n속성: ");if((p&2)!=0)b.append("READ ");if((p&8)!=0)b.append("WRITE ");if((p&4)!=0)b.append("WRITE_NO_RESPONSE ");if((p&16)!=0)b.append("NOTIFY ");if((p&32)!=0)b.append("INDICATE ");b.append("\n");}}info.setText(b.toString());ready=true;save.setEnabled(true);analyze.setEnabled(isLight());send.setEnabled(isLight());status.setText("● 연결 및 통신정보 확인 완료");});}
 @Override public void onCharacteristicRead(BluetoothGatt g,BluetoothGattCharacteristic c,int code){byte[] v=c.getValue();final byte[] data=v==null?null:v.clone();h.post(()->{if(g!=gatt)return;record("READ "+c.getUuid()+" status="+code+" "+hex(data));next();});}
 @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){byte[] v=c.getValue();final byte[] data=v==null?null:v.clone();h.post(()->{if(g==gatt)record("RX "+c.getUuid()+" "+hex(data));});}
 @Override public void onDescriptorWrite(BluetoothGatt g,BluetoothGattDescriptor d,int code){h.post(()->{if(g!=gatt)return;record("NOTIFY "+d.getCharacteristic().getUuid()+" status="+code);next();});}
 @Override public void onCharacteristicWrite(BluetoothGatt g,BluetoothGattCharacteristic c,int code){h.post(()->{if(g!=gatt)return;record("WRITE status="+code);next();});}
 };

 boolean isLight(){return ready&&selectedName.equalsIgnoreCase("EASY-LIGHT");}
 String hex(byte[] a){if(a==null)return "(없음)";StringBuilder b=new StringBuilder();for(byte v:a)b.append(String.format(Locale.US,"%02X ",v&255));return b.toString();}
 void record(String s){String old=log.getText().toString();if(old.length()>24000)old=old.substring(old.length()-16000);log.setText(old+"\n"+new java.text.SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date())+" "+s);}
 BluetoothGattCharacteristic find(String service,String characteristic){if(gatt==null)return null;BluetoothGattService s=gatt.getService(UUID.fromString(service));return s==null?null:s.getCharacteristic(UUID.fromString(characteristic));}
 String custom(String tail){return "02f00000-0000-0000-0000-00000000"+tail;}
 String standard(String tail){return "0000"+tail+"-0000-1000-8000-00805f9b34fb";}
 final Runnable timeout=()->{if(busy){record("응답 시간 초과: 연결을 다시 시도하세요.");closeGatt();status.setText("통신 시간 초과 / 연결 해제");}};
 void next(){h.removeCallbacks(timeout);busy=false;if(!isLight()||ops.isEmpty())return;busy=true;h.postDelayed(timeout,10000);try{ops.remove().run();}catch(Exception e){record("오류: "+e);next();}}
 void read(BluetoothGattCharacteristic c){if(c!=null&&(c.getProperties()&2)!=0)ops.add(()->{if(!gatt.readCharacteristic(c)){record("읽기 시작 실패 "+c.getUuid());next();}});}
 void subscribe(BluetoothGattCharacteristic c){if(c==null||(c.getProperties()&16)==0)return;ops.add(()->{BluetoothGattDescriptor d=c.getDescriptor(UUID.fromString(standard("2902")));if(d==null||!gatt.setCharacteristicNotification(c,true)){record("알림 설정 실패 "+c.getUuid());next();return;}d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);if(!gatt.writeDescriptor(d)){record("알림 요청 실패 "+c.getUuid());next();}});}
 void analyze(){if(!isLight()||busy)return;record("분석 시작: "+selected);for(String t:new String[]{"ff00","ff02","ff03"})read(find(custom("fe00"),custom(t)));for(String t:new String[]{"fc02","fff7"})read(find(standard("fc00"),standard(t)));subscribe(find(custom("fe00"),custom("ff02")));subscribe(find(standard("fc00"),standard("fc02")));subscribe(find(standard("fc00"),standard("fff7")));next();}
 void manual(){if(!isLight()||busy)return;String raw=hexInput.getText().toString().replaceAll("\\s+","");if(!raw.matches("[0-9a-fA-F]+")||raw.length()%2!=0||raw.length()>40){record("HEX 1~20바이트를 입력하세요.");return;}byte[] data=new byte[raw.length()/2];for(int i=0;i<data.length;i++)data[i]=(byte)Integer.parseInt(raw.substring(i*2,i*2+2),16);String t=channel.getSelectedItem().toString().toLowerCase(Locale.US);BluetoothGattCharacteristic c=t.equals("ff01")?find(custom("fe00"),custom(t)):find(standard("fc00"),standard(t));if(c==null)return;final BluetoothGatt target=gatt;new android.app.AlertDialog.Builder(this).setTitle("확인된 명령만 전송") .setMessage("미확인 명령은 기기 오작동을 일으킬 수 있습니다. "+t+" : "+hex(data)).setNegativeButton("취소",null).setPositiveButton("전송",(d,w)->{if(gatt!=target||!isLight()||busy)return;ops.add(()->{c.setWriteType((c.getProperties()&8)!=0?BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT:BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);c.setValue(data);record("TX "+c.getUuid()+" "+hex(data));if(!gatt.writeCharacteristic(c)){record("전송 시작 실패");next();}});next();}).show();}
 @Override protected void onDestroy(){stop();closeGatt();h.removeCallbacksAndMessages(null);super.onDestroy();}
}
