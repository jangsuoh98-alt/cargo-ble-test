V5: eight lantern slots, foreground reconnect, FFF4 control and FFF7 state. Hardware and APK build not verified.
